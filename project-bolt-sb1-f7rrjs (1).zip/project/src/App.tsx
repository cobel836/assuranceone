import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { HelmetProvider } from 'react-helmet-async';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './pages/Home';
import AutoInsurance from './pages/AutoInsurance';
import HomeInsurance from './pages/HomeInsurance';
import HealthInsurance from './pages/HealthInsurance';
import ProInsurance from './pages/ProInsurance';
import Blog from './pages/Blog';
import Contact from './pages/Contact';
import Compare from './pages/Compare';
import CookieConsent from './components/CookieConsent';
import { useScrollTop } from './hooks/useScrollTop';

function App() {
  useScrollTop();

  return (
    <HelmetProvider>
      <div className="min-h-screen bg-white flex flex-col">
        <Header />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/assurance-auto" element={<AutoInsurance />} />
            <Route path="/assurance-habitation" element={<HomeInsurance />} />
            <Route path="/assurance-sante" element={<HealthInsurance />} />
            <Route path="/assurance-pro" element={<ProInsurance />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/comparer" element={<Compare />} />
          </Routes>
        </main>
        <Footer />
        <CookieConsent />
      </div>
    </HelmetProvider>
  );
}

export default App;