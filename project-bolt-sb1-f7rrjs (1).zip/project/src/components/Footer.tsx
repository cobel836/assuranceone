import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Mail, Phone, ArrowRight, Shield } from 'lucide-react';

export default function Footer() {
  const navigate = useNavigate();

  const productLinks = [
    { name: 'Assurance Auto', path: '/assurance-auto' },
    { name: 'Assurance Habitation', path: '/assurance-habitation' },
    { name: 'Assurance Santé', path: '/assurance-sante' },
    { name: 'Assurance Pro', path: '/assurance-pro' },
  ];

  const usefulLinks = [
    { name: 'Blog', path: '/blog' },
    { name: 'Contact', path: '/contact' },
  ];

  const socialLinks = [
    { Icon: Facebook, url: 'https://facebook.com', label: 'Facebook' },
    { Icon: Twitter, url: 'https://twitter.com', label: 'Twitter' },
    { Icon: Instagram, url: 'https://instagram.com', label: 'Instagram' },
  ];

  const contactInfo = [
    { Icon: Mail, text: '', href: 'mailto:', label: 'Email' },
    { Icon: Phone, text: '', href: 'tel:', label: 'Téléphone' },
  ];

  const handleNavigation = (path: string) => {
    navigate(path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-gray-900">
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          {/* Logo and Social Links */}
          <div>
            <button 
              onClick={() => handleNavigation('/')}
              className="text-2xl font-bold text-white mb-6 flex items-center"
            >
              <Shield className="w-8 h-8 mr-2.5 fill-current" strokeWidth={1.5} />
              <div className="flex items-baseline">
                <span className="font-extrabold tracking-tight text-2xl">Assure</span>
                <span className="text-indigo-400 font-black text-2xl">One</span>
                <span className="text-lg ml-0.5 opacity-90">.fr</span>
              </div>
            </button>
            <p className="text-gray-400 mb-6 leading-relaxed">
              Votre partenaire de confiance pour trouver la meilleure assurance au meilleur prix.
            </p>
            <div className="flex space-x-4">
              {socialLinks.map(({ Icon, url, label }) => (
                <a
                  key={label}
                  href={url}
                  aria-label={label}
                  className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center text-gray-400 hover:bg-blue-600 hover:text-white transition-all duration-300"
                >
                  <Icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Products */}
          <div>
            <h4 className="text-lg font-semibold text-white mb-6">Nos Produits</h4>
            <ul className="space-y-4">
              {productLinks.map((link) => (
                <li key={link.path}>
                  <button
                    onClick={() => handleNavigation(link.path)}
                    className="text-gray-400 hover:text-white transition-colors inline-flex items-center group text-left w-full"
                  >
                    <ArrowRight className="w-4 h-4 mr-2 transform group-hover:translate-x-1 transition-transform" />
                    {link.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Useful Links */}
          <div>
            <h4 className="text-lg font-semibold text-white mb-6">Liens Utiles</h4>
            <ul className="space-y-4">
              {usefulLinks.map((link) => (
                <li key={link.path}>
                  <button
                    onClick={() => handleNavigation(link.path)}
                    className="text-gray-400 hover:text-white transition-colors inline-flex items-center group text-left w-full"
                  >
                    <ArrowRight className="w-4 h-4 mr-2 transform group-hover:translate-x-1 transition-transform" />
                    {link.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-lg font-semibold text-white mb-6">Contact</h4>
            <div className="space-y-4">
              {contactInfo.map(({ Icon, text, href, label }) => (
                <a
                  key={label}
                  href={href}
                  className="flex items-center text-gray-400 hover:text-white transition-colors group"
                >
                  <div className="w-10 h-10 rounded-lg bg-gray-800 flex items-center justify-center mr-3 group-hover:bg-blue-600 transition-colors">
                    <Icon className="w-5 h-5" />
                  </div>
                  {text}
                </a>
              ))}
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-16 pt-8 text-center">
          <p className="text-gray-400">&copy; 2024 Assure-One.fr. Tous droits réservés.</p>
        </div>
      </div>
    </footer>
  );
}