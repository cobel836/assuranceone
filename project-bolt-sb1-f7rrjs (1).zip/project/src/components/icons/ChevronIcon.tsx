import React from 'react';

export default function ChevronIcon() {
  return (
    <svg 
      fill="none" 
      height="24" 
      width="24" 
      viewBox="0 0 24 24"
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="1.5"
      stroke="currentColor"
      shapeRendering="geometricPrecision"
    >
      <path d="M6 9l6 6 6-6" />
    </svg>
  );
}