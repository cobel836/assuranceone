import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Shield, Menu, X } from 'lucide-react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const isHomePage = location.pathname === '/';

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Assurance Auto', path: '/assurance-auto' },
    { name: 'Assurance Habitation', path: '/assurance-habitation' },
    { name: 'Santé', path: '/assurance-sante' },
    { name: 'Blog', path: '/blog' }
  ];

  const handleNavigation = (path: string) => {
    navigate(path);
    setIsMenuOpen(false);
  };

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled || !isHomePage ? 'glass-card' : 'bg-transparent'
    }`}>
      <nav className="container mx-auto px-4">
        <div className="h-20 flex items-center justify-between">
          {/* Logo */}
          <div className="flex-shrink-0 mr-8">
            <button 
              onClick={() => handleNavigation('/')}
              className={`text-lg font-bold flex items-center transition-colors ${
                isScrolled || !isHomePage ? 'text-blue-600' : 'text-white'
              }`}
            >
              <Shield className="w-7 h-7 fill-current" strokeWidth={1.5} />
              <div className="ml-2.5 flex items-baseline">
                <span className="font-extrabold tracking-tight text-xl">Assure</span>
                <span className={`font-black text-xl ${isScrolled || !isHomePage ? 'text-indigo-500' : 'text-indigo-400'}`}>One</span>
                <span className={`text-sm ml-0.5 opacity-90 ${isScrolled || !isHomePage ? 'text-gray-600' : 'text-white'}`}>.fr</span>
              </div>
            </button>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-1 lg:space-x-2">
            {navLinks.map((link) => (
              <button
                key={link.path}
                onClick={() => handleNavigation(link.path)}
                className={`nav-link text-sm font-medium transition-colors px-3 py-2 rounded-md
                  ${isScrolled || !isHomePage 
                    ? 'text-gray-700 hover:text-blue-600 hover:bg-gray-50' 
                    : 'text-white/90 hover:text-white hover:bg-white/10'
                  } ${location.pathname === link.path ? 'after:w-full' : ''}`}
              >
                {link.name}
              </button>
            ))}
            <button 
              onClick={() => handleNavigation('/comparer')}
              className="btn-primary text-sm font-semibold whitespace-nowrap ml-4 px-5 py-2.5"
            >
              Comparer maintenant
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button 
            className={`md:hidden ${isScrolled || !isHomePage ? 'text-gray-600' : 'text-white'}`}
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-3 px-4 glass-card rounded-xl shadow-lg mt-2">
            <div className="flex flex-col space-y-2">
              {navLinks.map((link) => (
                <button
                  key={link.path}
                  onClick={() => handleNavigation(link.path)}
                  className="text-gray-700 hover:text-blue-600 hover:bg-gray-50 transition-colors text-sm font-medium text-left px-3 py-2 rounded-md"
                >
                  {link.name}
                </button>
              ))}
              <button
                onClick={() => handleNavigation('/comparer')}
                className="btn-primary text-sm font-semibold w-full mt-2 px-4 py-2.5"
              >
                Comparer maintenant
              </button>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}