import React, { useState, useEffect } from 'react';
import Cookies from 'js-cookie';
import { X, Cookie, Shield, Settings, Check, AlertCircle } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

const COOKIE_CONSENT_KEY = 'cookie_consent';
const CONSENT_ID_KEY = 'consent_id';
const CONSENT_TIMESTAMP_KEY = 'consent_timestamp';
const CONSENT_VERSION = '1.0';

interface CookieSettings {
  necessary: boolean;
  analytics: boolean;
  marketing: boolean;
  preferences: boolean;
}

interface ConsentLog {
  id: string;
  timestamp: string;
  version: string;
  settings: CookieSettings;
  userAgent: string;
}

const defaultSettings: CookieSettings = {
  necessary: true,
  analytics: false,
  marketing: false,
  preferences: false,
};

const cookieTypes = [
  {
    id: 'necessary',
    title: 'Cookies nécessaires',
    description: 'Ces cookies sont indispensables au fonctionnement du site.',
    required: true
  },
  {
    id: 'analytics',
    title: 'Cookies analytiques',
    description: 'Nous permettent de mesurer l\'audience.',
    required: false
  },
  {
    id: 'marketing',
    title: 'Cookies marketing',
    description: 'Pour des publicités pertinentes.',
    required: false
  },
  {
    id: 'preferences',
    title: 'Cookies de préférences',
    description: 'Mémorisent vos choix.',
    required: false
  }
];

export default function CookieConsent() {
  const [isOpen, setIsOpen] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [settings, setSettings] = useState<CookieSettings>(defaultSettings);
  const [notification, setNotification] = useState<{
    type: 'success' | 'error';
    message: string;
  } | null>(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      const hasConsent = Cookies.get(COOKIE_CONSENT_KEY);
      if (!hasConsent) {
        setIsOpen(true);
      } else {
        try {
          const savedSettings = JSON.parse(hasConsent);
          setSettings(savedSettings);
        } catch (error) {
          console.error('Error parsing cookie settings:', error);
          Cookies.remove(COOKIE_CONSENT_KEY);
          setIsOpen(true);
        }
      }
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const logConsent = (consentSettings: CookieSettings) => {
    const consentLog: ConsentLog = {
      id: uuidv4(),
      timestamp: new Date().toISOString(),
      version: CONSENT_VERSION,
      settings: consentSettings,
      userAgent: navigator.userAgent,
    };

    try {
      Cookies.set(CONSENT_ID_KEY, consentLog.id, { expires: 365, sameSite: 'strict' });
      Cookies.set(CONSENT_TIMESTAMP_KEY, consentLog.timestamp, { expires: 365, sameSite: 'strict' });
      const existingLogs = JSON.parse(localStorage.getItem('consent_logs') || '[]');
      localStorage.setItem('consent_logs', JSON.stringify([...existingLogs, consentLog]));
    } catch (error) {
      console.error('Error logging consent:', error);
      showNotification('error', 'Une erreur est survenue lors de l\'enregistrement de vos préférences');
    }
  };

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 5000);
  };

  const handleAcceptAll = () => {
    const newSettings = {
      necessary: true,
      analytics: true,
      marketing: true,
      preferences: true,
    };
    saveSettings(newSettings);
  };

  const handleRejectAll = () => {
    const newSettings = { ...defaultSettings };
    saveSettings(newSettings);
  };

  const saveSettings = (selectedSettings: CookieSettings) => {
    try {
      Cookies.set(COOKIE_CONSENT_KEY, JSON.stringify(selectedSettings), {
        expires: 365,
        sameSite: 'strict',
        path: '/'
      });
      logConsent(selectedSettings);
      setSettings(selectedSettings);
      setIsOpen(false);
      setShowDetails(false);
      showNotification('success', 'Vos préférences ont été enregistrées');
      applySettings(selectedSettings);
    } catch (error) {
      console.error('Error saving settings:', error);
      showNotification('error', 'Une erreur est survenue');
    }
  };

  const applySettings = (selectedSettings: CookieSettings) => {
    if (!selectedSettings.analytics) {
      ['_ga', '_gid', '_gat', '_ga_*'].forEach(pattern => {
        Object.keys(Cookies.get()).forEach(cookie => {
          if (cookie.match(pattern)) {
            Cookies.remove(cookie, { path: '/' });
          }
        });
      });
    }

    if (!selectedSettings.marketing) {
      ['_fbp', '_gcl_au', '_ttp', 'IDE'].forEach(cookie => {
        Cookies.remove(cookie, { path: '/' });
      });
    }

    if (!selectedSettings.preferences) {
      ['theme', 'language', 'user_preferences'].forEach(cookie => {
        Cookies.remove(cookie, { path: '/' });
      });
    }
  };

  if (!isOpen) {
    return (
      <>
        {notification && (
          <div 
            className={`fixed bottom-4 right-4 p-4 rounded-lg shadow-lg z-50 ${
              notification.type === 'success' ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'
            }`}
          >
            <div className="flex items-center">
              {notification.type === 'success' ? (
                <Check className="w-5 h-5 mr-2" />
              ) : (
                <AlertCircle className="w-5 h-5 mr-2" />
              )}
              <p>{notification.message}</p>
              <button
                onClick={() => setNotification(null)}
                className="ml-4 text-gray-500 hover:text-gray-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-4 left-4 p-3 bg-gray-800 text-white rounded-full shadow-lg hover:bg-gray-700 transition-colors z-50"
          aria-label="Gérer les cookies"
        >
          <Settings className="w-5 h-5" />
        </button>
      </>
    );
  }

  if (!showDetails) {
    return (
      <div className="fixed bottom-0 left-0 right-0 z-[9999]">
        <div className="bg-gradient-to-r from-gray-900 to-gray-800 text-white shadow-lg">
          <div className="container mx-auto px-4 py-4">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center space-x-3">
                <Cookie className="w-5 h-5 text-blue-400" />
                <p className="text-sm">
                  Nous utilisons des cookies pour améliorer votre expérience. 
                  <button 
                    onClick={() => setShowDetails(true)}
                    className="text-blue-400 hover:text-blue-300 ml-1 underline"
                  >
                    En savoir plus
                  </button>
                </p>
              </div>
              <div className="flex items-center space-x-3">
                <button
                  onClick={handleRejectAll}
                  className="px-4 py-1.5 text-sm bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors"
                >
                  Refuser
                </button>
                <button
                  onClick={handleAcceptAll}
                  className="px-4 py-1.5 text-sm bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors"
                >
                  Accepter
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[9999] overflow-y-auto bg-black bg-opacity-50 flex items-end sm:items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-2xl">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-2">
              <Shield className="w-6 h-6 text-blue-600" />
              <h2 className="text-xl font-semibold">Paramètres des cookies</h2>
            </div>
            <button
              onClick={() => setShowDetails(false)}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="space-y-6 mb-6">
            {cookieTypes.map((type) => (
              <div key={type.id} className="p-4 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors">
                <div className="flex items-start justify-between">
                  <div className="flex-grow">
                    <div className="flex items-center mb-1">
                      <h3 className="font-semibold text-gray-900">{type.title}</h3>
                      {type.required && (
                        <span className="ml-2 px-2 py-0.5 text-xs font-medium bg-blue-100 text-blue-800 rounded-full">
                          Requis
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-gray-600">{type.description}</p>
                  </div>
                  <div className="ml-4 flex-shrink-0">
                    <input
                      type="checkbox"
                      checked={settings[type.id as keyof CookieSettings]}
                      onChange={(e) => type.required ? null : setSettings({
                        ...settings,
                        [type.id]: e.target.checked
                      })}
                      disabled={type.required}
                      className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500 disabled:opacity-50"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="flex justify-end space-x-3">
            <button
              onClick={() => setShowDetails(false)}
              className="px-4 py-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              Retour
            </button>
            <button
              onClick={() => saveSettings(settings)}
              className="px-6 py-2 text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors"
            >
              Enregistrer
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}