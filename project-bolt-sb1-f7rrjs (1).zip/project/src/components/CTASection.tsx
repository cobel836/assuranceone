import React from 'react';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

interface CTASectionProps {
  title: string;
  description: string;
  buttonText: string;
  path: string;
  gradientFrom: string;
  gradientTo: string;
}

export default function CTASection({
  title,
  description,
  buttonText,
  path,
  gradientFrom,
  gradientTo
}: CTASectionProps) {
  const handleClick = () => {
    const element = document.querySelector(path);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="py-16 px-4 relative overflow-hidden">
      <div className={`absolute inset-0 bg-gradient-to-br ${gradientFrom} ${gradientTo} opacity-10`}></div>
      
      <div className="container mx-auto max-w-4xl relative">
        <div className="text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">{title}</h2>
          <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
            {description}
          </p>
          
          <button
            onClick={handleClick}
            className="inline-flex items-center px-8 py-4 text-lg font-semibold text-white rounded-xl
                     bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700
                     transform hover:-translate-y-0.5 transition-all duration-300 shadow-lg hover:shadow-xl"
          >
            {buttonText}
            <ArrowRight className="w-5 h-5 ml-2 animate-bounce-x" />
          </button>
        </div>
      </div>
    </div>
  );
}