import React, { useState, useCallback } from 'react';
import { ArrowLeft, Loader2, CheckCircle } from 'lucide-react';

interface Question {
  id: string;
  text: string;
  type: 'text' | 'number' | 'select' | 'email' | 'tel';
  options?: string[];
  placeholder?: string;
  required?: boolean;
}

interface QuestionnaireFormProps {
  questions: Question[];
  onSubmit: (answers: Record<string, string>) => Promise<boolean>;
  isSubmitting: boolean;
  error: string | null;
}

export default function QuestionnaireForm({ 
  questions, 
  onSubmit, 
  isSubmitting,
  error 
}: QuestionnaireFormProps) {
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [currentStep, setCurrentStep] = useState(0);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleInputChange = useCallback((questionId: string, value: string) => {
    setAnswers(prev => ({
      ...prev,
      [questionId]: value
    }));
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validate current question
    const currentQuestion = questions[currentStep];
    if (currentQuestion.required && !answers[currentQuestion.id]) {
      return;
    }

    if (currentStep < questions.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      try {
        const success = await onSubmit(answers);
        if (success) {
          setIsSuccess(true);
        }
      } catch (err) {
        console.error('Error submitting form:', err);
      }
    }
  };

  const currentQuestion = questions[currentStep];
  const isLastStep = currentStep === questions.length - 1;

  if (isSuccess) {
    return (
      <div className="text-center py-8">
        <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
        <h3 className="text-2xl font-bold text-gray-900 mb-2">Devis envoyé avec succès !</h3>
        <p className="text-gray-600">
          Nous avons bien reçu votre demande. Un conseiller vous contactera très prochainement.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {currentStep > 0 && (
        <button
          type="button"
          onClick={() => setCurrentStep(prev => prev - 1)}
          className="flex items-center text-gray-600 hover:text-blue-600 transition-colors mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Question précédente
        </button>
      )}

      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          {currentQuestion.text}
          {currentQuestion.required && <span className="text-red-500 ml-1">*</span>}
        </label>

        {currentQuestion.type === 'select' ? (
          <select
            value={answers[currentQuestion.id] || ''}
            onChange={(e) => handleInputChange(currentQuestion.id, e.target.value)}
            required={currentQuestion.required}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="">Sélectionnez une option</option>
            {currentQuestion.options?.map((option) => (
              <option key={option} value={option}>
                {option}
              </option>
            ))}
          </select>
        ) : (
          <input
            type={currentQuestion.type}
            value={answers[currentQuestion.id] || ''}
            onChange={(e) => handleInputChange(currentQuestion.id, e.target.value)}
            placeholder={currentQuestion.placeholder}
            required={currentQuestion.required}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        )}
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-lg">
          {error}
        </div>
      )}

      <button
        type="submit"
        disabled={isSubmitting}
        className="btn-primary w-full flex items-center justify-center py-3"
      >
        {isSubmitting ? (
          <Loader2 className="w-5 h-5 animate-spin" />
        ) : isLastStep ? (
          'Envoyer'
        ) : (
          'Question suivante'
        )}
      </button>

      <div className="text-center text-sm text-gray-500 mt-4">
        {`Question ${currentStep + 1} sur ${questions.length}`}
      </div>
    </form>
  );
}