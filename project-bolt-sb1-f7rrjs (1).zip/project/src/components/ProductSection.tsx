import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Car, Home, Heart, Briefcase, ArrowRight } from 'lucide-react';

const products = [
  {
    icon: Car,
    title: 'Assurance Auto',
    description: 'Protection complète pour votre véhicule avec les meilleures garanties.',
    path: '/assurance-auto',
    gradientFrom: 'from-blue-500',
    gradientTo: 'to-indigo-500',
    gradientVia: 'via-blue-400'
  },
  {
    icon: Home,
    title: 'Assurance Habitation',
    description: 'Protégez votre logement et vos biens en toute sérénité.',
    path: '/assurance-habitation',
    gradientFrom: 'from-indigo-500',
    gradientTo: 'to-purple-500',
    gradientVia: 'via-indigo-400'
  },
  {
    icon: Heart,
    title: 'Assurance Santé',
    description: 'Une couverture santé adaptée à vos besoins et votre budget.',
    path: '/assurance-sante',
    gradientFrom: 'from-purple-500',
    gradientTo: 'to-pink-500',
    gradientVia: 'via-purple-400'
  },
  {
    icon: Briefcase,
    title: 'Assurance Pro',
    description: 'Des solutions sur mesure pour protéger votre activité.',
    path: '/assurance-pro',
    gradientFrom: 'from-cyan-500',
    gradientTo: 'to-blue-500',
    gradientVia: 'via-cyan-400'
  },
];

export default function ProductSection() {
  const navigate = useNavigate();

  const handleNavigation = (path: string, isDevis: boolean = false) => {
    navigate(path);
    if (isDevis) {
      setTimeout(() => {
        const element = document.querySelector('#devis');
        if (element) {
          element.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);
    }
  };

  return (
    <section className="relative py-12 sm:py-16 md:py-20 bg-white overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-indigo-50/50 to-white"></div>
      
      <div className="container mx-auto px-4 relative">
        <div className="max-w-3xl mx-auto text-center mb-8 sm:mb-12 md:mb-16">
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-gray-900 mb-3 sm:mb-4">
            Nos Solutions d'Assurance
          </h2>
          <p className="text-sm sm:text-base text-gray-600 leading-relaxed px-4">
            Découvrez nos offres adaptées à tous vos besoins de protection
          </p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
          {products.map((product, index) => (
            <div
              key={index}
              className="gradient-border bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500"
            >
              <div className="relative bg-white rounded-2xl p-6 flex flex-col h-full">
                <div className={`w-12 h-12 bg-gradient-to-br ${product.gradientFrom} ${product.gradientTo} rounded-xl flex items-center justify-center mb-4 transform group-hover:scale-110 transition-transform duration-300`}>
                  <product.icon className="w-6 h-6 text-white" />
                </div>
                
                <h3 className="text-xl font-bold mb-2 text-gray-900">{product.title}</h3>
                <p className="text-sm text-gray-600 mb-6 flex-grow">{product.description}</p>
                
                <div className="space-y-3 mt-auto">
                  <button
                    onClick={() => handleNavigation(product.path)}
                    className="inline-flex items-center text-blue-600 font-semibold hover:text-blue-700 transition-colors group"
                  >
                    En savoir plus
                    <ArrowRight className="w-4 h-4 ml-2 transform group-hover:translate-x-1 transition-transform" />
                  </button>
                  
                  <button
                    onClick={() => handleNavigation(product.path, true)}
                    className="block w-full px-4 py-2.5 text-center text-white font-medium rounded-lg bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 transform hover:-translate-y-0.5 transition-all duration-300 shadow-md hover:shadow-lg"
                  >
                    Obtenir un devis
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}