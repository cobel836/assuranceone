import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Shield, Clock, PiggyBank } from 'lucide-react';

const searchSuggestions = [
  { text: 'Assurance Auto', path: '/assurance-auto', keywords: ['voiture', 'auto', 'automobile', 'véhicule', 'moto', 'scooter'] },
  { text: 'Assurance Habitation', path: '/assurance-habitation', keywords: ['maison', 'appartement', 'logement', 'habitat', 'locataire', 'propriétaire'] },
  { text: 'Assurance Santé', path: '/assurance-sante', keywords: ['santé', 'mutuelle', 'médical', 'soin', 'hospitalisation'] },
  { text: 'Assurance Pro', path: '/assurance-pro', keywords: ['professionnel', 'entreprise', 'commerce', 'société', 'responsabilité'] }
];

export default function Hero() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);

  const handleSearch = (path: string) => {
    navigate(path);
    setSearchTerm('');
    setShowSuggestions(false);
    setTimeout(() => {
      document.getElementById('devis')?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  const filteredSuggestions = searchTerm
    ? searchSuggestions.filter(suggestion =>
        suggestion.text.toLowerCase().includes(searchTerm.toLowerCase()) ||
        suggestion.keywords.some(keyword => 
          keyword.toLowerCase().includes(searchTerm.toLowerCase())
        )
      )
    : [];

  return (
    <div className="relative min-h-[90vh] sm:min-h-[80vh] flex items-center">
      <div className="absolute inset-0 bg-gradient-to-br from-blue-600 to-indigo-600"></div>
      
      <div className="container mx-auto px-4 relative z-10 pt-32 pb-12 sm:pt-40 md:pt-44 lg:pt-48">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold text-white mb-4 sm:mb-6 leading-tight">
            Simplifiez votre <span className="text-blue-200">assurance</span>
          </h1>
          <p className="text-base sm:text-lg md:text-xl text-blue-50 mb-8 sm:mb-12 leading-relaxed px-4">
            Comparez les meilleures offres d'assurance en quelques clics et 
            <span className="font-semibold"> économisez jusqu'à 40%</span>
          </p>
          
          <div className="search-container max-w-2xl mx-auto mb-8 sm:mb-16 relative">
            <div className="flex items-center bg-white/95 backdrop-blur-xl rounded-xl shadow-search-custom">
              <div className="flex items-center flex-grow p-2 sm:p-3">
                <Search className="w-5 h-5 text-blue-500 ml-2 flex-shrink-0" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => {
                    setSearchTerm(e.target.value);
                    setShowSuggestions(true);
                  }}
                  onFocus={() => setShowSuggestions(true)}
                  placeholder="Que souhaitez-vous assurer ?"
                  className="w-full px-3 py-2 focus:outline-none text-gray-700 text-sm sm:text-base bg-transparent placeholder-gray-500"
                />
              </div>
              <div className="p-1.5 sm:p-2 mr-1">
                <button 
                  onClick={() => handleSearch('/contact')}
                  className="btn-primary text-xs sm:text-sm whitespace-nowrap shadow-xl hover:shadow-2xl"
                >
                  Rechercher
                </button>
              </div>
            </div>

            {/* Search Suggestions */}
            {showSuggestions && (searchTerm || filteredSuggestions.length > 0) && (
              <div className="absolute left-0 right-0 top-full mt-2 bg-white rounded-xl shadow-xl overflow-hidden z-50">
                {filteredSuggestions.length > 0 ? (
                  <ul className="divide-y divide-gray-100">
                    {filteredSuggestions.map((suggestion, index) => (
                      <li key={index}>
                        <button
                          onClick={() => handleSearch(suggestion.path)}
                          className="w-full px-4 py-3 text-left hover:bg-gray-50 flex items-center text-gray-700"
                        >
                          <Search className="w-4 h-4 text-gray-400 mr-3" />
                          {suggestion.text}
                        </button>
                      </li>
                    ))}
                  </ul>
                ) : searchTerm && (
                  <div className="px-4 py-3 text-gray-500 text-sm">
                    Aucun résultat trouvé pour "{searchTerm}"
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6 max-w-4xl mx-auto px-4">
            {[
              { 
                icon: Shield, 
                text: '100% Sécurisé',
                bgColor: 'bg-blue-500'
              },
              { 
                icon: Clock, 
                text: 'Comparaison instantanée',
                bgColor: 'bg-violet-500'
              },
              { 
                icon: PiggyBank, 
                text: 'Meilleurs tarifs garantis',
                bgColor: 'bg-purple-500'
              }
            ].map(({ icon: Icon, text, bgColor }, index) => (
              <div
                key={index}
                className="bg-white/10 backdrop-blur-sm rounded-2xl p-4 transition-all duration-300 hover:bg-white/15 group"
              >
                <div className="flex items-center space-x-3">
                  <div className={`w-10 h-10 ${bgColor} rounded-xl flex items-center justify-center transition-transform duration-300 group-hover:scale-110`}>
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-white text-sm font-medium">{text}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}