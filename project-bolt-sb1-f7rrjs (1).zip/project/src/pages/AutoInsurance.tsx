import React from 'react';
import { Car, Shield, Gauge, Wrench, Coins, Check, AlertCircle, HelpCircle } from 'lucide-react';
import SEOHead from '../components/SEOHead';
import QuestionnaireForm from '../components/QuestionnaireForm';
import { useQuestionnaireSubmit } from '../hooks/useQuestionnaireSubmit';
import CTASection from '../components/CTASection';
import ChevronIcon from '../components/icons/ChevronIcon';
import { autoQuestions } from '../data/questionnaireData';

const coverageOptions = [
  {
    title: "Formule Basique",
    price: "À partir de 15€/mois",
    features: [
      "Responsabilité civile",
      "Protection juridique",
      "Assistance 24/7",
      "Bris de glace"
    ],
    recommended: false
  },
  {
    title: "Formule Intermédiaire",
    price: "À partir de 25€/mois",
    features: [
      "Tous les avantages de la formule Basique",
      "Vol et incendie",
      "Catastrophes naturelles",
      "Protection du conducteur"
    ],
    recommended: true
  },
  {
    title: "Formule Tous Risques",
    price: "À partir de 35€/mois",
    features: [
      "Tous les avantages de la formule Intermédiaire",
      "Dommages tous accidents",
      "Véhicule de remplacement",
      "Effets personnels"
    ],
    recommended: false
  }
];

const faqs = [
  {
    question: "Quelles sont les garanties obligatoires ?",
    answer: "La garantie responsabilité civile (RC) est la seule obligatoire par la loi. Elle couvre les dommages causés aux tiers lors d'un accident."
  },
  {
    question: "Comment est calculé le bonus-malus ?",
    answer: "Le coefficient bonus-malus évolue chaque année : -5% en l'absence d'accident responsable, +25% en cas d'accident responsable."
  },
  {
    question: "Puis-je assurer un véhicule qui n'est pas à mon nom ?",
    answer: "Oui, mais vous devez justifier d'un intérêt d'assurance (ex: conjoint, enfant, véhicule de fonction)."
  },
  {
    question: "Quel est le délai de déclaration d'un sinistre ?",
    answer: "Vous disposez de 5 jours ouvrés pour déclarer un sinistre à votre assureur, sauf en cas de vol (2 jours) ou de catastrophe naturelle (10 jours)."
  }
];

const advantages = [
  {
    icon: Shield,
    title: 'Protection Complète',
    description: 'Une couverture optimale pour votre véhicule et ses occupants.'
  },
  {
    icon: Gauge,
    title: 'Assistance 24/7',
    description: "Service d'assistance routière disponible 24h/24 et 7j/7."
  },
  {
    icon: Wrench,
    title: 'Réparation Garantie',
    description: 'Réseau de garages agréés pour des réparations de qualité.'
  },
  {
    icon: Coins,
    title: 'Tarifs Compétitifs',
    description: 'Des prix adaptés à votre profil et votre budget.'
  }
];

export default function AutoInsurance() {
  const { submitQuestionnaire, isSubmitting, error, isOffline } = useQuestionnaireSubmit('auto');

  const schema = {
    "@context": "https://schema.org",
    "@type": "Service",
    "name": "Assurance Auto AssureOne",
    "description": "Assurance automobile complète avec les meilleures garanties et tarifs",
    "provider": {
      "@type": "Organization",
      "name": "AssureOne"
    },
    "areaServed": {
      "@type": "Country",
      "name": "France"
    },
    "hasOfferCatalog": {
      "@type": "OfferCatalog",
      "name": "Assurances Auto",
      "itemListElement": advantages.map(advantage => ({
        "@type": "Offer",
        "itemOffered": {
          "@type": "Service",
          "name": advantage.title,
          "description": advantage.description
        }
      }))
    }
  };

  return (
    <>
      <SEOHead
        title="Assurance Auto - Devis Gratuit et Comparateur | AssureOne"
        description="Comparez les meilleures offres d'assurance auto et économisez jusqu'à 40%. Devis gratuit en ligne, garanties optimales et tarifs compétitifs."
        type="website"
        schema={schema}
      />

      <div className="pt-20">
        {/* Hero Section */}
        <div className="bg-gradient-to-br from-blue-600 to-indigo-600 py-20 px-4">
          <div className="container mx-auto max-w-4xl text-center text-white">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Assurance Auto</h1>
            <p className="text-xl text-blue-100 mb-8">
              La meilleure protection pour votre véhicule au meilleur prix
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <button 
                onClick={() => document.getElementById('devis')?.scrollIntoView({ behavior: 'smooth' })}
                className="px-8 py-3 bg-white text-blue-600 rounded-xl font-semibold hover:bg-blue-50 transition-colors"
              >
                Obtenir un devis
              </button>
              <button 
                onClick={() => document.getElementById('formules')?.scrollIntoView({ behavior: 'smooth' })}
                className="px-8 py-3 bg-blue-500 text-white rounded-xl font-semibold hover:bg-blue-400 transition-colors"
              >
                Voir nos formules
              </button>
            </div>
          </div>
        </div>

        {/* Advantages Section */}
        <div className="py-16 px-4 bg-gray-50">
          <div className="container mx-auto max-w-7xl">
            <h2 className="text-3xl font-bold text-center mb-12">Pourquoi choisir notre assurance auto ?</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {advantages.map((advantage, index) => (
                <div key={index} className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
                  <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center mb-4">
                    <advantage.icon className="w-6 h-6 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{advantage.title}</h3>
                  <p className="text-gray-600">{advantage.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Coverage Options */}
        <div id="formules" className="py-16 px-4">
          <div className="container mx-auto max-w-7xl">
            <h2 className="text-3xl font-bold text-center mb-12">Nos formules d'assurance</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {coverageOptions.map((option, index) => (
                <div 
                  key={index}
                  className={`relative bg-white rounded-xl shadow-lg overflow-hidden transition-transform hover:-translate-y-1 ${
                    option.recommended ? 'border-2 border-blue-500' : ''
                  }`}
                >
                  {option.recommended && (
                    <div className="absolute top-4 right-4">
                      <div className="bg-blue-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                        Recommandé
                      </div>
                    </div>
                  )}
                  <div className="p-6">
                    <h3 className="text-xl font-bold mb-2">{option.title}</h3>
                    <p className="text-blue-600 font-semibold mb-6">{option.price}</p>
                    <ul className="space-y-3">
                      {option.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-start">
                          <Check className="w-5 h-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <button 
                      onClick={() => document.getElementById('devis')?.scrollIntoView({ behavior: 'smooth' })}
                      className="w-full mt-6 px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-colors"
                    >
                      Obtenir un devis
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="py-16 px-4 bg-gray-50">
          <div className="container mx-auto max-w-4xl">
            <h2 className="text-3xl font-bold text-center mb-12">Questions fréquentes</h2>
            <div className="space-y-6">
              {faqs.map((faq, index) => (
                <div key={index} className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow">
                  <details className="group p-6">
                    <summary className="flex items-center justify-between cursor-pointer list-none">
                      <div className="flex items-center gap-3">
                        <HelpCircle className="w-5 h-5 text-blue-600" />
                        <span className="font-semibold">{faq.question}</span>
                      </div>
                      <span className="transition group-open:rotate-180">
                        <ChevronIcon />
                      </span>
                    </summary>
                    <p className="mt-4 text-gray-600 pl-8">{faq.answer}</p>
                  </details>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <CTASection
          title="Besoin d'une assurance auto sur mesure ?"
          description="Obtenez un devis personnalisé en quelques minutes et économisez jusqu'à 40% sur votre assurance auto."
          buttonText="Obtenir mon devis gratuit"
          path="#devis"
          gradientFrom="from-blue-500"
          gradientTo="to-indigo-500"
        />

        {/* Questionnaire Section */}
        <div id="devis" className="py-16 px-4 bg-gray-50">
          <div className="container mx-auto max-w-3xl">
            <div className="gradient-border bg-gradient-to-r from-blue-500 via-blue-400 to-indigo-500">
              <div className="bg-white p-6 sm:p-8 rounded-2xl">
                <h2 className="text-2xl font-bold mb-6 text-center">Obtenir un devis gratuit</h2>
                {isOffline && (
                  <div className="mb-6 p-4 bg-yellow-50 border-l-4 border-yellow-400 text-yellow-700">
                    <div className="flex items-center">
                      <AlertCircle className="w-5 h-5 mr-2" />
                      <p>Mode hors ligne : Votre demande sera envoyée automatiquement lorsque la connexion sera rétablie.</p>
                    </div>
                  </div>
                )}
                <QuestionnaireForm
                  questions={autoQuestions}
                  onSubmit={submitQuestionnaire}
                  isSubmitting={isSubmitting}
                  error={error}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}