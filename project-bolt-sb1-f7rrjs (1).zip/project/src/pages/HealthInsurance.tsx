import React from 'react';
import { Heart, Stethoscope, Pill, Building2, Clock, Check, AlertCircle, HelpCircle } from 'lucide-react';
import SEOHead from '../components/SEOHead';
import QuestionnaireForm from '../components/QuestionnaireForm';
import { useQuestionnaireSubmit } from '../hooks/useQuestionnaireSubmit';
import CTASection from '../components/CTASection';
import ChevronIcon from '../components/icons/ChevronIcon';
import { healthQuestions } from '../data/questionnaireData';

// ... rest of the imports and constants remain the same ...

export default function HealthInsurance() {
  // ... existing code remains the same until the FAQ section ...

  return (
    <>
      <SEOHead
        title="Assurance Santé - Devis Gratuit | AssureOne"
        description="Protégez votre santé avec notre mutuelle santé. Devis gratuit en ligne, garanties optimales et remboursements rapides."
        type="website"
        schema={schema}
      />

      {/* ... other sections remain the same ... */}

      {/* FAQ Section - Updated with ChevronIcon */}
      <div className="py-16 px-4 bg-gray-50">
        <div className="container mx-auto max-w-4xl">
          <h2 className="text-3xl font-bold text-center mb-12">Questions fréquentes</h2>
          <div className="space-y-6">
            {faqs.map((faq, index) => (
              <div key={index} className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow">
                <details className="group p-6">
                  <summary className="flex items-center justify-between cursor-pointer list-none">
                    <div className="flex items-center gap-3">
                      <HelpCircle className="w-5 h-5 text-purple-600" />
                      <span className="font-semibold">{faq.question}</span>
                    </div>
                    <span className="transition group-open:rotate-180">
                      <ChevronIcon />
                    </span>
                  </summary>
                  <p className="mt-4 text-gray-600 pl-8">{faq.answer}</p>
                </details>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ... rest of the component remains the same ... */}
    </>
  );
}