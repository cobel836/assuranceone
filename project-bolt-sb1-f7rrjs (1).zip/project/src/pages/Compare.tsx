import React, { useState, useEffect } from 'react';
import { Shield, ArrowRight, Check, AlertCircle, Filter, SlidersHorizontal } from 'lucide-react';
import SEOHead from '../components/SEOHead';

interface InsuranceOffer {
  id: string;
  provider: string;
  logo: string;
  price: number;
  rating: number;
  features: string[];
  advantages: string[];
  type: 'auto' | 'home' | 'health' | 'pro';
}

const mockOffers: InsuranceOffer[] = [
  {
    id: '1',
    provider: 'AssurePlus',
    logo: 'https://images.unsplash.com/photo-1560472355-536de3962603?w=100&h=100&fit=crop',
    price: 45.99,
    rating: 4.8,
    features: ['Responsabilité civile', 'Protection juridique', 'Assistance 24/7'],
    advantages: ['Franchise réduite', 'Bonus fidélité', 'App mobile'],
    type: 'auto'
  },
  {
    id: '2',
    provider: 'SecurLife',
    logo: 'https://images.unsplash.com/photo-1572021335469-31706a17aaef?w=100&h=100&fit=crop',
    price: 39.99,
    rating: 4.5,
    features: ['Responsabilité civile', 'Protection conducteur', 'Bris de glace'],
    advantages: ['Paiement mensuel', 'Devis immédiat', 'Service client premium'],
    type: 'auto'
  },
  {
    id: '3',
    provider: 'SafeGuard',
    logo: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=100&h=100&fit=crop',
    price: 42.99,
    rating: 4.6,
    features: ['Tous risques', 'Vol et incendie', 'Assistance Europe'],
    advantages: ['Parrainage récompensé', 'Zéro papier', 'Résiliation facile'],
    type: 'auto'
  }
];

export default function Compare() {
  const [selectedType, setSelectedType] = useState<'auto' | 'home' | 'health' | 'pro'>('auto');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 100]);
  const [sortBy, setSortBy] = useState<'price' | 'rating'>('price');
  const [filteredOffers, setFilteredOffers] = useState<InsuranceOffer[]>(mockOffers);
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    let filtered = mockOffers.filter(offer => 
      offer.type === selectedType &&
      offer.price >= priceRange[0] &&
      offer.price <= priceRange[1]
    );

    filtered.sort((a, b) => 
      sortBy === 'price' ? a.price - b.price : b.rating - a.rating
    );

    setFilteredOffers(filtered);
  }, [selectedType, priceRange, sortBy]);

  const schema = {
    "@context": "https://schema.org",
    "@type": "Service",
    "name": "Comparateur d'assurances AssureOne",
    "description": "Comparez les meilleures offres d'assurance en temps réel"
  };

  return (
    <>
      <SEOHead
        title="Comparateur d'Assurances en Ligne | AssureOne"
        description="Comparez en temps réel les meilleures offres d'assurance. Trouvez l'assurance idéale au meilleur prix."
        schema={schema}
      />

      <div className="pt-20">
        {/* Hero Section */}
        <div className="bg-gradient-to-br from-blue-600 to-indigo-600 py-16 px-4">
          <div className="container mx-auto max-w-4xl text-center text-white">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Comparateur d'Assurances
            </h1>
            <p className="text-xl text-blue-100 mb-8">
              Trouvez l'assurance idéale en quelques clics
            </p>
          </div>
        </div>

        {/* Main Content */}
        <div className="py-12 px-4">
          <div className="container mx-auto max-w-7xl">
            {/* Insurance Type Selector */}
            <div className="flex flex-wrap gap-4 mb-8 justify-center">
              {[
                { type: 'auto', label: 'Auto' },
                { type: 'home', label: 'Habitation' },
                { type: 'health', label: 'Santé' },
                { type: 'pro', label: 'Pro' }
              ].map(({ type, label }) => (
                <button
                  key={type}
                  onClick={() => setSelectedType(type as any)}
                  className={`px-6 py-3 rounded-xl font-medium transition-all ${
                    selectedType === type
                      ? 'bg-blue-600 text-white shadow-lg'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>

            {/* Filters and Sort */}
            <div className="mb-8">
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="flex items-center gap-2 px-4 py-2 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
              >
                <Filter className="w-5 h-5" />
                Filtres et tri
              </button>

              {showFilters && (
                <div className="mt-4 p-6 bg-white rounded-xl shadow-lg">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Price Range */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Budget mensuel maximum
                      </label>
                      <input
                        type="range"
                        min="0"
                        max="100"
                        value={priceRange[1]}
                        onChange={(e) => setPriceRange([0, Number(e.target.value)])}
                        className="w-full"
                      />
                      <div className="text-sm text-gray-600 mt-1">
                        {`0€ - ${priceRange[1]}€`}
                      </div>
                    </div>

                    {/* Sort */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Trier par
                      </label>
                      <select
                        value={sortBy}
                        onChange={(e) => setSortBy(e.target.value as 'price' | 'rating')}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      >
                        <option value="price">Prix croissant</option>
                        <option value="rating">Meilleures notes</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Results */}
            <div className="grid grid-cols-1 gap-6">
              {filteredOffers.map((offer) => (
                <div
                  key={offer.id}
                  className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow p-6"
                >
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-6 items-center">
                    {/* Provider Info */}
                    <div className="flex items-center gap-4">
                      <img
                        src={offer.logo}
                        alt={offer.provider}
                        className="w-16 h-16 rounded-lg object-cover"
                      />
                      <div>
                        <h3 className="font-bold text-lg">{offer.provider}</h3>
                        <div className="flex items-center text-yellow-400">
                          {'★'.repeat(Math.floor(offer.rating))}
                          <span className="text-gray-600 text-sm ml-1">
                            ({offer.rating})
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Features */}
                    <div className="md:col-span-2">
                      <h4 className="font-semibold mb-2">Garanties incluses</h4>
                      <ul className="grid grid-cols-2 gap-2">
                        {offer.features.map((feature, index) => (
                          <li key={index} className="flex items-center text-sm">
                            <Check className="w-4 h-4 text-green-500 mr-2" />
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Price and CTA */}
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-600 mb-2">
                        {offer.price.toFixed(2)}€ <span className="text-sm text-gray-600">/mois</span>
                      </div>
                      <button className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                        Souscrire
                      </button>
                    </div>
                  </div>

                  {/* Advantages */}
                  <div className="mt-6 pt-6 border-t">
                    <h4 className="font-semibold mb-2">Avantages</h4>
                    <div className="flex flex-wrap gap-2">
                      {offer.advantages.map((advantage, index) => (
                        <span
                          key={index}
                          className="px-3 py-1 bg-blue-50 text-blue-600 rounded-full text-sm"
                        >
                          {advantage}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}