import React from 'react';
import SEOHead from '../components/SEOHead';
import Hero from '../components/Hero';
import ProductSection from '../components/ProductSection';

export default function Home() {
  const schema = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "AssureOne",
    "url": "https://assureone.fr",
    "logo": "https://assureone.fr/logo.png",
    "description": "Comparateur d'assurances en ligne - Auto, Habitation, Santé et Pro",
    "address": {
      "@type": "PostalAddress",
      "addressCountry": "FR"
    },
    "sameAs": [
      "https://facebook.com/assureone",
      "https://twitter.com/assureone",
      "https://instagram.com/assureone"
    ]
  };

  return (
    <>
      <SEOHead
        title="AssureOne - Comparateur d'Assurances en Ligne | Auto, Habitation, Santé, Pro"
        description="Comparez et économisez jusqu'à 40% sur vos assurances. Devis gratuit en ligne pour votre assurance auto, habitation, santé ou professionnelle."
        schema={schema}
      />
      <Hero />
      <ProductSection />
    </>
  );
}