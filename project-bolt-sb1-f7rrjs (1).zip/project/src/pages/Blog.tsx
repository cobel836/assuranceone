import React, { useState } from 'react';
import { Calendar, User, ArrowRight, Search, WifiOff } from 'lucide-react';
import SEOHead from '../components/SEOHead';
import { useBlogPosts } from '../hooks/useBlogPosts';
import { categories } from '../data/blogData';

export default function Blog() {
  const { posts, loading, isOffline } = useBlogPosts();
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredPosts = posts.filter(post => {
    const matchesCategory = selectedCategory ? post.category === selectedCategory : true;
    const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const schema = {
    "@context": "https://schema.org",
    "@type": "Blog",
    "name": "Blog AssureOne - Actualités et Conseils Assurance",
    "description": "Découvrez nos articles, guides et conseils sur l'assurance auto, habitation, santé et professionnelle.",
    "publisher": {
      "@type": "Organization",
      "name": "AssureOne",
      "logo": {
        "@type": "ImageObject",
        "url": "https://assureone.fr/logo.png"
      }
    },
    "blogPost": posts.map(post => ({
      "@type": "BlogPosting",
      "headline": post.title,
      "description": post.excerpt,
      "datePublished": post.date,
      "author": {
        "@type": "Person",
        "name": post.author
      },
      "image": post.imageUrl
    }))
  };

  return (
    <>
      <SEOHead
        title="Blog Assurance - Guides et Conseils | AssureOne"
        description="Découvrez nos articles, guides et conseils pour tout comprendre sur l'assurance. Expertise et actualités sur l'assurance auto, habitation, santé et professionnelle."
        type="article"
        schema={schema}
      />
      
      <div className="pt-20">
        <div className="bg-gradient-to-br from-gray-900 to-gray-800 py-20 px-4">
          <div className="container mx-auto max-w-4xl text-center text-white">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Blog Assurance</h1>
            <p className="text-xl text-gray-300 mb-8">
              Actualités, conseils et guides pratiques
            </p>
          </div>
        </div>

        {isOffline && (
          <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 my-4 mx-auto max-w-6xl">
            <div className="flex items-center">
              <WifiOff className="h-5 w-5 text-yellow-400 mr-3" />
              <p className="text-sm text-yellow-700">
                Mode hors ligne : Affichage des articles en cache. Certains contenus peuvent ne pas être à jour.
              </p>
            </div>
          </div>
        )}

        <div className="py-16 px-4">
          <div className="container mx-auto max-w-6xl">
            <div className="mb-8 space-y-4 sm:space-y-0 sm:flex sm:items-center sm:justify-between">
              <div className="flex items-center space-x-4">
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Toutes les catégories</option>
                  {categories.map((category) => (
                    <option key={category} value={category}>
                      {category}
                    </option>
                  ))}
                </select>
              </div>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Rechercher un article..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 w-full sm:w-64"
                />
              </div>
            </div>

            {loading ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {filteredPosts.map((post) => (
                  <article 
                    key={post.id}
                    className="gradient-border bg-gradient-to-r from-gray-500 via-gray-400 to-gray-500"
                    itemScope
                    itemType="http://schema.org/BlogPosting"
                  >
                    <div className="bg-white p-6 rounded-2xl h-full">
                      {post.imageUrl && (
                        <div className="mb-4 rounded-lg overflow-hidden">
                          <img 
                            src={post.imageUrl} 
                            alt={post.title}
                            className="w-full h-48 object-cover transform hover:scale-105 transition-transform duration-300"
                            loading="lazy"
                            itemProp="image"
                          />
                        </div>
                      )}
                      <div className="flex items-center space-x-4 mb-4 text-sm text-gray-600">
                        <span className="px-3 py-1 bg-gray-100 rounded-full">{post.category}</span>
                        <time 
                          className="flex items-center"
                          itemProp="datePublished" 
                          dateTime={post.date}
                        >
                          <Calendar className="w-4 h-4 mr-1" />
                          {new Date(post.date).toLocaleDateString('fr-FR', {
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric'
                          })}
                        </time>
                        <div className="flex items-center">
                          <User className="w-4 h-4 mr-1" />
                          <span itemProp="author">{post.author}</span>
                        </div>
                      </div>
                      <h2 
                        className="text-xl font-bold mb-3"
                        itemProp="headline"
                      >
                        {post.title}
                      </h2>
                      <p 
                        className="text-gray-600 mb-4"
                        itemProp="description"
                      >
                        {post.excerpt}
                      </p>
                      <button 
                        className="text-blue-600 font-medium inline-flex items-center group"
                        aria-label={`Lire l'article : ${post.title}`}
                      >
                        Lire la suite
                        <ArrowRight className="w-4 h-4 ml-2 transform group-hover:translate-x-1 transition-transform" />
                      </button>
                    </div>
                  </article>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}