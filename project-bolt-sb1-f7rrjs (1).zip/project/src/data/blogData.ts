import { BlogPost } from '../types/blog';

export const categories = [
  'Auto',
  'Habitation',
  'Santé',
  'Pro',
  'Conseils',
  'Actualités'
] as const;

export const defaultBlogPosts: BlogPost[] = [
  {
    id: '1',
    title: 'Comment choisir la meilleure assurance auto ?',
    excerpt: 'Guide complet pour comprendre les différentes garanties et options disponibles...',
    content: `
      # Comment choisir la meilleure assurance auto ?

      Choisir une assurance auto peut sembler complexe avec toutes les options disponibles...
      
      ## Les différentes garanties
      
      1. Responsabilité civile
      2. Garantie tous risques
      3. Protection du conducteur
      
      ## Comment comparer les offres
      
      - Analysez vos besoins
      - Comparez les garanties
      - Étudiez les franchises
    `,
    date: '2024-03-15',
    author: 'Jean Dupont',
    category: 'Auto',
    imageUrl: 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&q=80'
  },
  // Ajoutez d'autres articles ici
];