interface Question {
  id: string;
  text: string;
  type: 'text' | 'number' | 'select' | 'email' | 'tel';
  options?: string[];
  placeholder?: string;
  required?: boolean;
}

export const autoQuestions: Question[] = [
  {
    id: 'fullName',
    text: 'Nom et prénom',
    type: 'text',
    placeholder: 'Jean Dupont',
    required: true
  },
  {
    id: 'email',
    text: 'Adresse email',
    type: 'email',
    placeholder: 'jean.dupont@email.com',
    required: true
  },
  {
    id: 'phone',
    text: 'Numéro de téléphone',
    type: 'tel',
    placeholder: '06 12 34 56 78',
    required: true
  },
  {
    id: 'vehicleType',
    text: 'Type de véhicule',
    type: 'select',
    options: ['Citadine', 'Berline', 'SUV', 'Utilitaire', 'Sport'],
    required: true
  },
  {
    id: 'vehicleYear',
    text: 'Année du véhicule',
    type: 'number',
    placeholder: '2020',
    required: true
  }
];

export const homeQuestions: Question[] = [
  {
    id: 'fullName',
    text: 'Nom et prénom',
    type: 'text',
    placeholder: 'Jean Dupont',
    required: true
  },
  {
    id: 'email',
    text: 'Adresse email',
    type: 'email',
    placeholder: 'jean.dupont@email.com',
    required: true
  },
  {
    id: 'phone',
    text: 'Numéro de téléphone',
    type: 'tel',
    placeholder: '06 12 34 56 78',
    required: true
  },
  {
    id: 'propertyType',
    text: 'Type de logement',
    type: 'select',
    options: ['Appartement', 'Maison', 'Loft', 'Studio'],
    required: true
  },
  {
    id: 'surface',
    text: 'Surface en m²',
    type: 'number',
    placeholder: '75',
    required: true
  }
];

export const healthQuestions: Question[] = [
  {
    id: 'fullName',
    text: 'Nom et prénom',
    type: 'text',
    placeholder: 'Jean Dupont',
    required: true
  },
  {
    id: 'email',
    text: 'Adresse email',
    type: 'email',
    placeholder: 'jean.dupont@email.com',
    required: true
  },
  {
    id: 'phone',
    text: 'Numéro de téléphone',
    type: 'tel',
    placeholder: '06 12 34 56 78',
    required: true
  },
  {
    id: 'age',
    text: 'Âge',
    type: 'number',
    placeholder: '30',
    required: true
  },
  {
    id: 'coverage',
    text: 'Niveau de couverture souhaité',
    type: 'select',
    options: ['Basique', 'Intermédiaire', 'Premium'],
    required: true
  }
];

export const proQuestions: Question[] = [
  {
    id: 'fullName',
    text: 'Nom et prénom',
    type: 'text',
    placeholder: 'Jean Dupont',
    required: true
  },
  {
    id: 'email',
    text: 'Adresse email',
    type: 'email',
    placeholder: 'jean.dupont@email.com',
    required: true
  },
  {
    id: 'phone',
    text: 'Numéro de téléphone',
    type: 'tel',
    placeholder: '06 12 34 56 78',
    required: true
  },
  {
    id: 'company',
    text: 'Nom de l\'entreprise',
    type: 'text',
    placeholder: 'Ma Société SARL',
    required: true
  },
  {
    id: 'sector',
    text: 'Secteur d\'activité',
    type: 'select',
    options: ['Commerce', 'Services', 'Industrie', 'Construction', 'Autre'],
    required: true
  }
];