import { initializeApp } from 'firebase/app';
import { 
  getFirestore, 
  connectFirestoreEmulator,
  initializeFirestore,
  persistentLocalCache,
  persistentMultipleTabManager
} from 'firebase/firestore';
import { getAuth, connectAuthEmulator } from 'firebase/auth';

// Development fallback configuration
const devConfig = {
  apiKey: 'fake-api-key',
  authDomain: 'localhost',
  projectId: 'demo-project',
  storageBucket: 'demo-bucket',
  messagingSenderId: '123456789',
  appId: '1:123456789:web:abcdef',
  measurementId: 'G-DEMO123'
};

const getFirebaseConfig = () => {
  // Check if all required environment variables are present
  const requiredVars = [
    'VITE_FIREBASE_API_KEY',
    'VITE_FIREBASE_AUTH_DOMAIN',
    'VITE_FIREBASE_PROJECT_ID',
    'VITE_FIREBASE_STORAGE_BUCKET',
    'VITE_FIREBASE_MESSAGING_SENDER_ID',
    'VITE_FIREBASE_APP_ID',
    'VITE_FIREBASE_MEASUREMENT_ID'
  ];

  const missingVars = requiredVars.filter(varName => !import.meta.env[varName]);

  if (missingVars.length > 0) {
    console.warn('Missing Firebase configuration. Using development fallback.');
    return devConfig;
  }

  return {
    apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
    authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
    projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
    storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
    messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
    appId: import.meta.env.VITE_FIREBASE_APP_ID,
    measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID
  };
};

// Initialize Firebase with error handling
let app;
let db;
let auth;

try {
  app = initializeApp(getFirebaseConfig());

  // Initialize Firestore with persistent cache and multi-tab support
  db = initializeFirestore(app, {
    localCache: persistentLocalCache({
      tabManager: persistentMultipleTabManager()
    })
  });

  // Initialize Auth
  auth = getAuth(app);

  // Enable emulators in development
  if (import.meta.env.DEV) {
    connectAuthEmulator(auth, 'http://localhost:9099', { disableWarnings: true });
    connectFirestoreEmulator(db, 'localhost', 8080);
  }
} catch (error) {
  console.error('Error initializing Firebase:', error);
  // Initialize with development fallback if there's an error
  app = initializeApp(devConfig);
  db = initializeFirestore(app, {
    localCache: persistentLocalCache({
      tabManager: persistentMultipleTabManager()
    })
  });
  auth = getAuth(app);
}

// Enhanced error handling
const handleFirebaseError = (error: any): string => {
  if (error?.code === 'permission-denied') {
    return "Vous n'avez pas les autorisations nécessaires. Veuillez vous connecter.";
  }
  if (error?.code === 'not-found') {
    return "La ressource demandée n'existe pas.";
  }
  if (error?.code === 'unavailable') {
    return "Le service est temporairement indisponible. Vos données seront synchronisées automatiquement lorsque la connexion sera rétablie.";
  }
  if (error?.code === 'failed-precondition') {
    return "Une erreur de configuration est survenue. Veuillez rafraîchir la page.";
  }
  return "Une erreur est survenue. Vos données seront sauvegardées localement et synchronisées ultérieurement.";
};

export { auth, db, handleFirebaseError };