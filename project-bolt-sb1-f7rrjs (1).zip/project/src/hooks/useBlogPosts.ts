import { useState, useEffect } from 'react';
import { collection, getDocs, query, orderBy, where } from 'firebase/firestore';
import { db, handleFirebaseError } from '../lib/firebase';
import { BlogPost } from '../types/blog';
import { defaultBlogPosts } from '../data/blogData';
import localforage from 'localforage';

const CACHE_KEY = 'blogPosts';
const CACHE_DURATION = 1000 * 60 * 5; // 5 minutes

export const useBlogPosts = () => {
  const [posts, setPosts] = useState<BlogPost[]>(defaultBlogPosts);
  const [loading, setLoading] = useState(true);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);

  useEffect(() => {
    const handleOnlineStatus = () => {
      setIsOffline(!navigator.onLine);
    };

    window.addEventListener('online', handleOnlineStatus);
    window.addEventListener('offline', handleOnlineStatus);

    const fetchPosts = async () => {
      try {
        // Try to get cached data first
        const cached = await localforage.getItem<{data: BlogPost[], timestamp: number}>(CACHE_KEY);
        const now = Date.now();

        if (cached && (now - cached.timestamp < CACHE_DURATION)) {
          setPosts(cached.data);
          setLoading(false);
          return;
        }

        if (!navigator.onLine) {
          setPosts(defaultBlogPosts);
          setLoading(false);
          return;
        }

        const q = query(
          collection(db, 'blog_posts'),
          where('status', '==', 'published'),
          orderBy('date', 'desc')
        );
        
        const querySnapshot = await getDocs(q);
        const fetchedPosts = querySnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        })) as BlogPost[];
        
        const postsToUse = fetchedPosts.length > 0 ? fetchedPosts : defaultBlogPosts;
        setPosts(postsToUse);
        
        // Cache the fetched data
        await localforage.setItem(CACHE_KEY, {
          data: postsToUse,
          timestamp: now
        });

      } catch (err) {
        console.error('Error fetching posts:', err);
        setPosts(defaultBlogPosts);
        setIsOffline(true);
      } finally {
        setLoading(false);
      }
    };

    fetchPosts();

    return () => {
      window.removeEventListener('online', handleOnlineStatus);
      window.removeEventListener('offline', handleOnlineStatus);
    };
  }, []);

  return { posts, loading, isOffline };
};