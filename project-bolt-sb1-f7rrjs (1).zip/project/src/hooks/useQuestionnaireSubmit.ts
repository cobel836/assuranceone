import { useState, useCallback, useEffect } from 'react';
import { collection, addDoc, serverTimestamp, doc } from 'firebase/firestore';
import { db, handleFirebaseError } from '../lib/firebase';
import confetti from 'canvas-confetti';
import localforage from 'localforage';

const OFFLINE_QUEUE_KEY = 'offlineSubmissions';

export interface QuestionnaireSubmission {
  insuranceType: 'auto' | 'home' | 'health' | 'pro';
  answers: Record<string, string>;
  status: 'pending' | 'contacted' | 'completed';
}

export const useQuestionnaireSubmit = (insuranceType: QuestionnaireSubmission['insuranceType']) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);

  useEffect(() => {
    const handleOnlineStatus = () => {
      const online = navigator.onLine;
      setIsOffline(!online);
      
      if (online) {
        syncOfflineSubmissions();
      }
    };

    window.addEventListener('online', handleOnlineStatus);
    window.addEventListener('offline', handleOnlineStatus);

    return () => {
      window.removeEventListener('online', handleOnlineStatus);
      window.removeEventListener('offline', handleOnlineStatus);
    };
  }, []);

  const syncOfflineSubmissions = async () => {
    try {
      const offlineData = await localforage.getItem<any[]>(OFFLINE_QUEUE_KEY) || [];
      
      if (offlineData.length === 0) return;

      for (const submission of offlineData) {
        try {
          await addDoc(collection(db, 'questionnaires'), submission);
        } catch (err) {
          console.error('Error syncing submission:', err);
        }
      }

      await localforage.removeItem(OFFLINE_QUEUE_KEY);
    } catch (err) {
      console.error('Error during sync:', err);
    }
  };

  const triggerConfetti = useCallback(() => {
    const duration = 3000;
    const end = Date.now() + duration;

    (function frame() {
      confetti({
        particleCount: 7,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors: ['#4F46E5', '#3B82F6', '#6366F1']
      });
      confetti({
        particleCount: 7,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors: ['#4F46E5', '#3B82F6', '#6366F1']
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    }());
  }, []);

  const submitQuestionnaire = useCallback(async (answers: Record<string, string>): Promise<boolean> => {
    setIsSubmitting(true);
    setError(null);

    try {
      const requiredFields = ['fullName', 'email', 'phone'];
      const missingFields = requiredFields.filter(field => !answers[field]);
      
      if (missingFields.length > 0) {
        throw new Error('Veuillez remplir tous les champs obligatoires');
      }

      const submissionData = {
        insuranceType,
        answers,
        status: 'pending' as const,
        createdAt: serverTimestamp(),
        metadata: {
          source: 'web',
          version: '1.0',
          userAgent: navigator.userAgent,
          timestamp: new Date().toISOString(),
          isOffline: !navigator.onLine
        }
      };

      if (!navigator.onLine) {
        const offlineData = await localforage.getItem<any[]>(OFFLINE_QUEUE_KEY) || [];
        await localforage.setItem(OFFLINE_QUEUE_KEY, [...offlineData, submissionData]);
        setError("Votre demande a été enregistrée et sera envoyée automatiquement lorsque la connexion sera rétablie.");
        triggerConfetti();
        return true;
      }

      await addDoc(collection(db, 'questionnaires'), submissionData);
      triggerConfetti();
      return true;

    } catch (err) {
      console.error('Erreur lors de la soumission:', err);
      setError(handleFirebaseError(err));
      return false;
    } finally {
      setIsSubmitting(false);
    }
  }, [insuranceType, triggerConfetti]);

  return {
    submitQuestionnaire,
    isSubmitting,
    error,
    isOffline
  };
};